/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bigdataselenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author sanil
 */
public class BigDataSelenium {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WebDriver driver=new FirefoxDriver();
        driver.get("file:///C:/Users/sanil/Desktop/UX-Html/index%20(1).html");
        //WebDriver firefoxDriver=new FirefoxDriver();
         //firefoxDriver.get("Http://www.google.com");
         driver.manage().window().maximize();
         String actualTitle = driver.getTitle();
         System.out.println(""+actualTitle);
         String expectedTitle = " Target ";
          if (expectedTitle.equals(actualTitle))

              {

                     System.out.println("Title is Correct");

              }

             else

              {

                     System.out.println("Title is incorrect");

              }
           
            WebElement ele1=driver.findElement(By.linkText("Help"));
            ele1.click();
            WebElement ele2=driver.findElement(By.linkText("Site Map"));
            ele2.click();
          //driver.close();
        // TODO code application logic here
    }
    
}
