/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package feedbackformselenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author sanil
 */
public class FeedbackformSelenium {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WebDriver driver=new FirefoxDriver();
        driver.get("file:///C:/Users/sanil/Desktop/UX-Html/FeedbackForm.html");
        //driver.get("http://bigdataanalytics.net23.net/FeedbackForm.html");
        driver.manage().window().maximize();
       // WebElement yname = driver.findElement(By.xpath("//input[@type='file']"));
        //yname.sendKeys("aks");
       WebElement yname = driver.findElement(By.name("name"));
        yname.clear();
        yname.sendKeys("user123");
        WebElement email = driver.findElement(By.xpath("//input[@type='email']"));
        email.sendKeys("abc@gmail.com");
        //WebElement choose = driver.findElement(By.id("select"));
        //choose.click();
        WebElement choose = driver.findElement(By.id("select"));
        WebElement rev=driver.findElement(By.xpath("//*[contains(text(), 'I found a bug')]"));
        rev.click();
         WebElement message = driver.findElement(By.name("message"));
        message.sendKeys("There is a error on Home page");
        WebElement submit = driver.findElement(By.xpath("//input[@type='submit']"));
        submit.click();
        //driver.find_elements_by_xpath("//*[contains(text(), 'My Button')]")
         //choose.Select(ByText("HighSchool")); 
        
        // TODO code application logic here
    }
    
}
